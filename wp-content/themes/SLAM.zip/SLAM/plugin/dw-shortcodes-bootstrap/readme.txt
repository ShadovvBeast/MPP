=== DW Shortcodes Bootstrap ===
Contributors: Designwall Team
Donate link: http://designwall.com
Tags: shortcode, shortcodes, bootstrap, buttons, grid, responsive, widget
Requires at least: 3.0
Tested up to: 3.4.2
Stable tag: 2.0
License: GNU General Public License v2.0
License URI: http://www.gnu.org/licenses/gpl-2.0.html

DW Shortcodes Bootstrap allow easy implementation of Wordpress shortcodes coming along with responsive and the twitter bootstrap. 

== Description ==

DW Shortcodes Bootstrap allow quick and easy implementation of Wordpress shortcodes by the rich-editor for TinyMCE coming along with responsive feature and the sleek twitter bootstrap style.

* Built with the WordPress API.
* Support Twitter Bootstrap http://twitter.github.com/bootstrap/
* Widgets builder
* Well Documented

More info and complete documentation at:  
http://designwall.com

== Installation ==

1. Unzip files.
2. Upload the folder into your plugins directory.
3. Activate the plugin.
4. Add new shortcodes based on your needs.
5. Have fun!

== Change log ==

= 2.0 =
* Improve tabs buider.
* Add plugin options page.
* Change buttons style.
* Minified boostrap library.
* Move shortcode php files to lib folder.
= 1.0.1 =
* Add new feature Grid builder
* Fix wrong url for icons & tab buider.
= 1.0 =
* First version out.


== Frequently Asked Questions ==
* No FAQ yet

== Upgrade Notice ==
* No

== Screenshots ==
1. screenshot-1.jpg
2. screenshot-2.jpg
3. screenshot-3.png