jQuery('a.qtfgcolorbox').colorbox({transition:"elastic", height: '80%' , rel:"landscapes"});
jQuery('.gallery-item a').colorbox({transition:"elastic", height: '80%' , rel:"landscapes"});