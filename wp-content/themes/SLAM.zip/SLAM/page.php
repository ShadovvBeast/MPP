<?php 

get_header(); 

get_template_part( 'loop', 'page' ); 

get_footer(); 

?>