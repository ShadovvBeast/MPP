<?php 

get_header(); ?>


    	<div class=" qw-innerbox qw-WCcontainer">
    			<div class="qw-inside-innerbox">

				<?php woocommerce_content();?>
				</div>
		</div>
		</div>

	<?php 
get_footer(); 

?>