<?php 
 
get_header(); 
 
get_template_part( 'loop', 'archivepodcast' );


get_footer();

?>