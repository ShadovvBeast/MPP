<?php 
 
get_header(); 
 
get_template_part( 'loop', 'archiveevent' );


get_footer();

?>