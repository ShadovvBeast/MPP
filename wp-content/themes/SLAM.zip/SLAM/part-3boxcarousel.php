
    <?php 
    // _homepage_3boxcarousel ========================================================================
    if(get_option(THEME_SHORTNAME.'_homepage_3boxcarousel') == 'enabled' ){
    ?>    
    <div class="qw-indexmodule" >
        
          <?php include ('includes/CircularContentCarousel/carousel.php'); ?>
       
    </div>       
     <?php }  ?>