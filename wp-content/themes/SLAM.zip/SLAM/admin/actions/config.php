<?php

	define ('BEATPORTACTIONS','enabled');

?>