<div class="pull-right span4 qw-musicplayer" >
  <div class="qw-musicplayer-box"  > <a href="#" id="prevTrack" class="qw-player-control-btn">Next</a>
    <div class="qw-player-control-playbtn" id="musicplayer-box">
      <div class="ui360 ui360-vis qw-player-control-ui" > <a id="playerlink" href="none.mp3"></a> </div>
    </div>
    <a href="#" id="nextTrack" class="qw-player-control-btn">Prev</a>
    <div id="qw-volumeFader" class="hidden-phone hidden-tablet">
      <div id="qw-volumeFader-bg" > </div>
    </div>
    <a class="qw-musicplayer-label" href="#" id="qwPlaylistSwitch"><i class="icon-th-list"></i></a> </div>
 	
</div>
