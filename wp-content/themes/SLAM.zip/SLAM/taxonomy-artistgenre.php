<?php 
 
get_header(); 
 
get_template_part( 'loop', 'archiveartist' );


get_footer();

?>