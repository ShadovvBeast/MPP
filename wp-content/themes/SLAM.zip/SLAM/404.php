<?php 
 
get_header(); 
 
?>

<h1>404: Sorry, this page doesn't exist</h1>
</div>
<?php

get_footer();

?>