<?php

		$fields=array(

				array('','section','','Slider details'),

				array('_cd_slider_link','text','','Slider link'),

			

				array('_cd_slider_image','img','','900*300 for sliders')

		

				

			

	

				);

?>