// JavaScript Document
(function($){
	//console.log('asdddd');
	
	
})(jQuery);