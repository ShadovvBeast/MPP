<?php

		$fields=array(

				array('','section','','General info','frontend_show'),
				array('_artist_nationality','text','','Nationality','frontend_show','repeat'),
				array('_artist_resident','text','','Resident in','frontend_show'),
				array('','separator','','','frontend_show'),
				array('','section','','Links','frontend_show'),
				array('_artist_website','link','','Website','frontend_show'),
				array('_artist_facebook','link','','Facebook (http://...)','frontend_show'),
				array('_artist_beatport','link','','Beatport (http://...)','frontend_show'),
				array('_artist_soundcloud','link','','Soundcloud (http://...)','frontend_show'),
				array('_artist_mixcloud','link','','Mixcloud (http://...)','frontend_show'),
				array('_artist_myspace','link','','Myspace (http://...)','frontend_show'),
				array('_artist_residentadv','link','','Resident Advisor (http://...)','frontend_show'),
				array('_artist_twitter','link','','Twitter (http://...)','frontend_show'),
				array('','separator','','','frontend_show'),
				array('','section','','Youtube videos','frontend_show'),
				array('_artist_youtubevideo1','medialink','','Youtube video','frontend_show'),
				array('_artist_youtubevideo2','medialink','','Youtube video','frontend_show'),
				array('_artist_youtubevideo3','medialink','','Youtube video','frontend_show'),
				array('','separator','','','frontend_show'),
				array('','section','','Booking contacts','frontend_show'),
				array('_artist_booking_contact_name','text','','Agency','frontend_show'),
				array('_artist_booking_contact_phone','text','','Phone','frontend_show'),
				array('_artist_booking_contact_email','text','','Email','frontend_show'),
				array('','section','','Header image','frontend_hide'),
				array('_artist_headerimage','img','','Width: 1200 px for header image','frontend_hide'),
				

				

	

				);

		

		

		

	

?>