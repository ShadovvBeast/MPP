<?php 

get_header();

get_template_part( 'loop', 'artist' );

get_footer(); 

?>