<div class="pagination">

    <p>

        <?php posts_nav_link(

			'&nbsp;',

			'<span class="btn_page_back" href="#">Articoli precedenti</span>',

			' <span class="btn_page_ahead" href="#">Articoli successivi</span>'); 

        ?>

    </p>

</div>

