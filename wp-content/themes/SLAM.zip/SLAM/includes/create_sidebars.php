<?php
// sidebars are created into the initialize section, placed into initialize.php file
// other sidebars chould be added by extending this $theme_sidebars array
// example:  array_push($theme_sidebars,array('Sidebar Name to use in the theme', 'Sidebar description for humans');


$theme_sidebars = array(

	 array(

		 'Home row left',

		'' 

	),

	array(

		 'Home row middle',

		'' 

	),

	array(

		 'Home row right',

		'' 

	),

	array(

		 'Home sidebar right',

		'' 

	),

	array(

		 'Archive sidebar right',

		'' 

	),

	array(

		 'Footer row left',

		'' 

	),

	array(

		 'Footer row middle',

		'' 

	),

	array(

		 'Footer row right',

		'' 

	),

	array(

		 'Podcast sidebar right',

		'' 

	),

	array(

		 'Artist sidebar right',

		'' 

	),

	array(

		 'Single sidebar right',

		'' 

	),

	array(

		 'Release sidebar right',

		'' 

	) ,
	array(

		 'Single page sidebar',

		'' 

	)

);

?>