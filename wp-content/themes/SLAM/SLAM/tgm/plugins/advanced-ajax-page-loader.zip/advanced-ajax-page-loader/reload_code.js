function AAPL_reload_code() {
//This file is generated from the admin panel - dont edit here! 
jQuery("body").delay(800).promise().done(function(){
FB.XFBML.parse();twttr.widgets.load();initializeAfterAjax($);FB.XFBML.parse();
});
}

function AAPL_click_code(thiss) {
//This file is generated from the admin panel - dont edit here! 
// highlight the current menu item
jQuery("ul.nav li").each(function() {
	jQuery(this).removeClass("current-menu-item").removeClass("active");
});
jQuery(thiss).parent("li").addClass("current-menu-item").addClass("active");
}

function AAPL_data_code(dataa) {
//This file is generated from the admin panel - dont edit here! 
jQuery.qwRevCss = jQuery(jQuery.parseHTML(dataa,true)).filter("[data-revstyles]");
}