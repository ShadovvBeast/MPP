<?php
/*
		This is the template that is automatically included by the widget

*/
?>
<ul>
<?php

if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post(); 
$postId = $query->post->ID;
$span = "span12 marginfix borderbottom";
?>		
	<li>	
		


		<a class="qw-blocklink" href="<?php the_permalink(); ?>">
			<?php
				if($instance['showthumbnail']=='true'){
	           		if(has_post_thumbnail())  {
	           			the_post_thumbnail('thumbnail','class=qw-widget-thumbnail');
                    }
				}
			?>
			<span class="qw-widg-singleline	<?php echo(($instance['shorten_titles']=='yes')? 'ellipsis':'');?>"></span>
				<a class="" href="<?php the_permalink(); ?>">
					<?php the_title(); ?>
				</a>
			</span>
		</a>







<!--

		<div class="row-fluid">
	    	<?php
				if($instance['showthumbnail']=='true'){
	           		if(has_post_thumbnail())  { 
	           			?>
	           			<div class="span4 thumbcol"><a class="thumbnail" href="<?php the_permalink(); ?>">
	           				<?php
	                  		the_post_thumbnail('','class=qw-widget-thumbnail');
	                  		?>
	                  	</a></div>
	                  	<?php
	                  	$span = 'span8';
	                 }
				}
			?>

			<div class="<?php echo $span;?>">
	       		<p class="title <?php echo(($instance['shorten_titles']=='yes')? 'ellipsis':'');?>"><a class="" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></p>
	       		<p class="details ellipsis"><?php echo get_the_term_list( $postId, 'category', ' ', ', ', ' ' ); ?></p>
	        </div>
	        <div class="canc"></div>
	    </div>-->
	</li>

<?php endwhile; endif; 

 if(isset($instance['archivelink']) && isset($instance['archivelink_text'])){
	if($instance['archivelink'] == 'show'){
	 	 	echo ' <li class="text-right "><a href="'.get_post_type_archive_link('post').'">'.$instance['archivelink_text'].' <i class="icon-chevron-right animated"></i></a></li>';
 	} 
 }
?>
</ul>
<?php 